﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesPoo
{
    public class Fechas
    {
        private int _Dia;
        private int _Mes;
        private int _Anio;

        //constructor datos ------------------- 
        public Fechas(int dia, int mes, int anio)
        {
            this._Dia = dia;
            this._Mes = mes;
            this._Anio = anio;
        }

        //Constructor fecha actual defecto ------------------- 
        public Fechas()
        {
            DateTime Hoy = DateTime.Today;
            
            int Anio = Hoy.Year;
            int Mes = Hoy.Month;
            int Dia = Hoy.Day;
            //DateTime today = DateTime.Now;
            //DateTime date = DateTime.Now.....;

            this._Dia =Dia;
            this._Mes = Mes;
            this._Anio = Anio;
        }
        string mesescrito;
        public string MostrarConPalabras() {
            
            switch (this._Mes) {

                case 1:
                    mesescrito = "Enero";
                    break;
                case 2:
                    mesescrito = "Febrero";
                    break;
                case 3:
                    mesescrito = "Marzo";
                    break;
                case 4:
                    mesescrito = "Abril";
                    break;

                case 5:
                    mesescrito = "Mayo";
                    break;
                case 6:
                    mesescrito = "Junio";
                    break;
                case 7:
                    mesescrito = "Julio";
                    break;
                case 8:
                    mesescrito = "Agosto";
                    break;
                case 9:
                    mesescrito = "Septiembre";
                    break;
                case 10:
                    mesescrito = "Octubre";
                    break;
                case 11:
                    mesescrito = "Noviembre";
                    break;
                case 12:
                    mesescrito = "Diciembre";
                    break;

            }
            int Dia = this._Dia;
            int Anio = this._Anio;


            //switch (Mes)
            //{
            //    case 01:
            //        return $"Red = {(int)c}";
            //    case 02:
            //        return $"Green = {(int)c}";
            //    case Color.Blue:
            //        return $"Blue = {(int)c}";
            //    default:
            //        return "Invalid color";
            //}


            return Dia.ToString() + "/" + mesescrito +"/"+Anio.ToString();
        }

        /// validar Fecha
        public bool Validar(int dia, int mes, int anio)
        {
            string Validadar = dia.ToString() + "/" + mes.ToString() + "/" + anio;

            try
            {
                DateTime.Parse(Validadar);
                return true;
            }
            catch (Exception)
            {

                return false;
            }


        }



        //overrride tostring ------------------- 
        public override string ToString()
        {
            return $"{_Dia.ToString().PadLeft(2, '0')}/{_Mes.ToString().PadLeft(2, '0')}/{_Anio.ToString().PadLeft(2, '0')}";

        }

        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is Fechas))
            {
                return false;
            }

            return this._Dia == ((Fechas)obj)._Dia &&
                   this._Mes == ((Fechas)obj)._Mes &&
                   this._Anio == ((Fechas)obj)._Anio;
        }

        public static bool operator == (Fechas f1, Fechas f2)
        {
            bool igual;
            DateTime fe1 = new DateTime((f1._Anio), (f1._Mes), (f1._Dia));
            DateTime fe2 = new DateTime((f2._Anio), (f2._Mes), (f2._Dia));
            if (fe1.Equals(fe2))
            {
                igual= true;
            }
            else
            {
                igual=false;
            }

                return igual;

        }

        public static bool operator !=(Fechas f1, Fechas f2)
        {
            bool igual;
            DateTime fe1 = new DateTime((f1._Anio), (f1._Mes), (f1._Dia));
            DateTime fe2 = new DateTime((f2._Anio), (f2._Mes), (f2._Dia));
            if (fe1.Equals(fe2))
            {
                igual = true;
            }
            else
            {
                igual = false;
            }

            return igual;
        }
    }


}

