﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesPoo
{
     public class triangulos
    {
        private int _LadoA;
        private int _LadoB;
        private int _LadoC;

        public string mostrarLadoA() { return _LadoA.ToString(); }
        public string mostrarLadoB() { return _LadoB.ToString(); }
        public string mostrarLadoC() { return _LadoB.ToString(); }

        public triangulos(int ladoA, int ladoB, int ladoC)
        {
            this._LadoA = ladoA;
            this._LadoB = ladoB;
            this._LadoC = ladoC;
        }
        public triangulos()
        {
            this._LadoA = 1;
            this._LadoB = 1;
            this._LadoC = 1;
        }

        public bool Validar(int ladoA, int ladoB, int ladoC) {
            bool valido = false;
            if (ladoA + ladoB > ladoC && ladoA + ladoC > ladoB && ladoB + ladoC > ladoA)
            {
                valido = true;
                return valido;
            }
            else
            {
                return valido;
            }
             
        }

        public string TipoTriangulo() {
            string TipoT;

            double sumasBC = Math.Pow(this._LadoC, 2) + Math.Pow(this._LadoB, 2);

            if (this._LadoA == sumasBC)
            {
                TipoT = "Triangulo Rectangulo";
            }
            else if (this._LadoA < sumasBC)
            {
                TipoT = "Triangulo Acutángulo";
            }
            else {
                TipoT = "triángulo obtusángulo";

            
            }
            return TipoT;
//            Si LadoA2 = LadoB2 + LadoC2 Se forma un triángulo rectángulo.
//ii.Si LadoA2 > LadoB2 + LadoC2 Se forma un triángulo obtusángulo. <>
//iii.Si LadoA2<LadoB2 +LadoC2 Se forma un triángulo acutángulo.

        }

        public string MostrarDatos() {
            
            int perimetro = this._LadoA + this._LadoB + this._LadoC;
            double p = (this._LadoA + this._LadoB + this._LadoC)/2;
            double Area = Math.Pow((p * (p - this._LadoA) * (p - this._LadoB) * (p - this._LadoC)), 2);
            return $" El perimetro del triangulo es de: {perimetro} Su Area es de {Area}"; 
        }





    }
}
