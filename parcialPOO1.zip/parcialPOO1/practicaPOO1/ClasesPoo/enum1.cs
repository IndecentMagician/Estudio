﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesPoo
{
    public class enum1
    {
        public enum Season
        {
            Enero, //31 días 
            Febrero, //28 días o 29 en año bisiesto --- public static bool IsLeapYear (año);
            Marzo, //31 días
            Abril, //30 días
            Mayo, //31 días
            Junio, // 30 Dias
            Julio, //31 días
            Agosto,	//31 días
            Septiembre,	//30 días
            Octubre,	//31 días
            Noviembre,	//30 días
            Diciembre	//31 días
        }
    }
}
