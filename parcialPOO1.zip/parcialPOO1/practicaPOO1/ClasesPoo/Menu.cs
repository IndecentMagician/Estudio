﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ClasesPoo
{
    public class Menu
    {
        private int _Seleccion;
        private string[] _Opciones;
        private string _Prompt;

        public Menu(string[] opciones, string prompt)
        {
            this._Opciones = opciones;
            this._Prompt = prompt;
            //pos. por defecto
            this._Seleccion = 0;
        }

        //Armado del Menu

        public void MenuArmado()
        {
            //$ variables y @ utilizar renglones
            WriteLine($@"

  ██████╗  ██████╗ ███████╗████████╗ ██████╗ ███╗   ██╗
  ██╔══██╗██╔═══██╗██╔════╝╚══██╔══╝██╔═══██╗████╗  ██║
  ██████╔╝██║   ██║███████╗   ██║   ██║   ██║██╔██╗ ██║
  ██╔══██╗██║   ██║╚════██║   ██║   ██║   ██║██║╚██╗██║
  ██████╔╝╚██████╔╝███████║   ██║   ╚██████╔╝██║ ╚████║
  ╚═════╝  ╚═════╝ ╚══════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═══╝
                                                     

     ░ Utilizar las flechas para desplazarse
     ░ Presione Enter Para Ejecutar
     ░ { _Prompt} .

");
            //recorrido del array de opciones
            for (int i = 0; i < _Opciones.Length; i++)
            {
                string Punto;
                string Opcion = _Opciones[i];
                //si el index del obj se encuentra en _seleccion agrega el punto e invierte color
                if (i == _Seleccion)
                {
                    ForegroundColor = ConsoleColor.White;
                    BackgroundColor = ConsoleColor.Magenta;
                    Punto = "*";
                }
                else
                {
                    ForegroundColor = ConsoleColor.Black;
                    BackgroundColor = ConsoleColor.Magenta;
                    Punto = " ";
                }
                WriteLine($"{Punto} <<:[ {Opcion} ]:>>");

            }
            //reseteamos los colores para no contaminar la pantalla
            ResetColor();
           
        }

        
        public int Iniciar()
        {
            ConsoleKey Presionada;
            do
            {
                //limpiamos la pantalla
                Clear();
                //mostramos el menu armado
                MenuArmado();
                //inicio de captura de teclas
                ConsoleKeyInfo InfoKey = ReadKey(true);
                Presionada = InfoKey.Key;
                //refresco pantalla mediante el do/while con seleccion actual
                //en caso de llegar al limite de opciones crea un bucle
                if (Presionada == ConsoleKey.UpArrow)
                {
                    _Seleccion--;
                    if (_Seleccion==-1)
                    {
                        _Seleccion = _Opciones.Length - 1;                       
                    }
                }
                else if(Presionada == ConsoleKey.DownArrow)
                {
                    _Seleccion++;
                    if (_Seleccion == _Opciones.Length)
                    {
                        _Seleccion = 0;
                    }
                }

                //al presionar Enter salimos del recorrido
            } while (Presionada != ConsoleKey.Enter);
            //retornamos la seleccion al Int para seleccionar el case en switch
            return _Seleccion;

        }

    }
}
