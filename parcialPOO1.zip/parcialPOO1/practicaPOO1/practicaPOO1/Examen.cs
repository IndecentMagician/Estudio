﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//agrego la clase Poo y Console 
using ClasesPoo;
using static System.Console;

namespace practicaPOO1
{
    internal class Examen
    {
        //iniciamos nueva consola
        public static void Iniciar()
        {
            //cambiamos el titulo a la nueva consola
            Title = "Examen";
            //llamada al metodo de menu en esta consola
            IniciarMenuExamen();

            //Console.ReadLine();
            //en este punto regresa a la consola anterior
            Title = "don-B0$$-co.";

        }

        //inicia el menu examen
        private static void IniciarMenuExamen()
        {
            //cambiamos el prompt a nuevas instrucciones
            string Prompt = "Ejercicios Resueltos Del Examen:";
            //pasamos el contenido del menu
            string[] Opciones = { "Fechas", "Triangulos", "Atras" };
            //creamos el nuevo menu con las opciones otorgadas
            Menu menu = new Menu(Opciones, Prompt);
            //indicamos que Seleccion es = al int _Seleccion
            int Seleccion = menu.Iniciar();
            // en caso de presionar enter, Seleccion se encontraria en una posicion
            // la cual la derivamos al switch
            switch (Seleccion)
            {
                case 0:
                    Fechas();
                    break;
                case 1:
                    Triangulos();
                    break;
                case 2:
                    Salir();
                    break;
            }

        }

        //METODOS A EJECUTAR DEL SWITCH
        // contenidos del programa
        private static void Salir()
        {
            //realmente no sale, simplemente sale del bucle y regresa a la consola anterior
        }

        /// <summary>
        /// ///////////////////////
        /// ///Ejercicio Triangulos
        /// ////////////////
        /// </summary>
        public static void Triangulos()
        {
            Clear();
            WriteLine("Se inicia test...");
            WriteLine("Se Crean los triangulos");
            triangulos T1 = new triangulos();
            triangulos T2 = new triangulos(4,5,6);
            WriteLine("Primer Triangulo");
            WriteLine("Lado : A" + T1.mostrarLadoA() + "Lado B: " + T1.mostrarLadoB()+ "Lado C: " + T1.mostrarLadoC());
            WriteLine(T1.MostrarDatos());
            WriteLine("Segndo Triangulo");
            WriteLine("Lado A: " + T2.mostrarLadoA() + "Lado B: " + T2.mostrarLadoB() + "Lado C: " + T2.mostrarLadoC());
            WriteLine(T2.MostrarDatos());
            
            WriteLine("Presione una tecla para regresar <<<< ");
            ReadLine();
            IniciarMenuExamen();
        }
        /// <summary>
        /// ///////////////////////
        /// ///Ejercicio Fechas
        /// ////////////////
        /// </summary>
        private static void Fechas()
        {
            Clear();
            WriteLine("Se inicia test...");
            Fechas F1 = new Fechas();
            Fechas F2 = new Fechas(2,6,1985);
            WriteLine("Fecha inicial");
            WriteLine(F1.MostrarConPalabras());
            WriteLine("Fecha Cargada");
            WriteLine(F2.MostrarConPalabras());
            WriteLine("Fecha con letras");
            WriteLine(F2.ToString());
            WriteLine(F1.ToString());
            WriteLine("Las Fechas son iguales?");
            WriteLine(F1 + " y " + F2);
            WriteLine(F2 == F1);
            WriteLine("Las Fechas son iguales?");
            Fechas F3 =new Fechas(2,6,1985);
            WriteLine(F2 + " y " + F3);
            WriteLine(F2 == F3);
            WriteLine("Presione una tecla para regresar <<<< ");
            ReadLine();
            IniciarMenuExamen();

        }

    }
}
