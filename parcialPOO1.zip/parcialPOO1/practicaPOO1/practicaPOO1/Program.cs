﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//agrego la clase Poo y el Console 
using ClasesPoo;
using static System.Console;

namespace practicaPOO1
{
    internal class Program
    {
            //ConsoleKeyInfo InfoKey =ReadKey();
            //if (InfoKey.Key == ConsoleKey.Enter)
            //{
            //}
        static void Main(string[] args)
        {
            Title = "don-b0$$-co.";
            IniciarMenu();


        }

        private static void IniciarMenu()
        {
            string Prompt = "Parcial Poo 2022";
            string[] Opciones = { "Test", "About", "Salir" };
            Menu menu = new Menu(Opciones, Prompt);
            int Seleccion = menu.Iniciar();
            switch (Seleccion)
            {
                case 0:
                    Ejecutar();
                    break;
                case 1:
                    About();
                    break;
                case 2:
                    Salir();
                    break;
            }

        }
        private static void Salir() {
            WriteLine("Presione una tecla para salir");
            ReadLine();
            Environment.Exit(0);        
        }

        //podria cargarse en otro lado para ahorrar codigo
        private static void About() {
            Clear();
            WriteLine(@"
           ▄▄▄▄    ▒█████    ██████ ▄▄▄█████▓ ▒█████   ███▄    █ 
           ▓█████▄ ▒██▒  ██▒▒██    ▒ ▓  ██▒ ▓▒▒██▒  ██▒ ██ ▀█   █ 
           ▒██▒ ▄██▒██░  ██▒░ ▓██▄   ▒ ▓██░ ▒░▒██░  ██▒▓██  ▀█ ██▒
           ▒██░█▀  ▒██   ██░  ▒   ██▒░ ▓██▓ ░ ▒██   ██░▓██▒  ▐▌██▒
           ░▓█  ▀█▓░ ████▓▒░▒██████▒▒  ▒██▒ ░ ░ ████▓▒░▒██░   ▓██░
           ░▒▓███▀▒░ ▒░▒░▒░ ▒ ▒▓▒ ▒ ░  ▒ ░░   ░ ▒░▒░▒░ ░ ▒░   ▒ ▒ 
           ▒░▒   ░   ░ ▒ ▒░ ░ ░▒  ░ ░    ░      ░ ▒ ▒░ ░ ░░   ░ ▒░
            ░    ░ ░ ░ ░ ▒  ░  ░  ░    ░      ░ ░ ░ ▒     ░   ░ ░ 
            ░          ░ ░        ░               ░ ░           ░ 
                 ░      IG: @BostonJoker                          ");

            ReadLine();
            IniciarMenu();
        }
        private static void Ejecutar(){
            Clear();
            WriteLine("Se inicia test...");
            //crea la instancia del obj examen utilizada como layer de consola
            Examen Examen = new Examen();
            //inicia el nuevo layer
            Examen.Iniciar();
            //al salir del bucle del nuevo layer
            WriteLine("Presione una tecla para regresar al menu <<<<");
            ReadLine();
            IniciarMenu();

        }
    }
}
